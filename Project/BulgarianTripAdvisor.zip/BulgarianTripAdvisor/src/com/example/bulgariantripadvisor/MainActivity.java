package com.example.bulgariantripadvisor;
import com.facebook.android.Facebook;

import android.view.View;
import android.os.Bundle;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends Activity implements OnClickListener {
	ImageView pic, button;
	Facebook fb;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		String APP_ID = "546615005379508";
		
		fb = new Facebook(APP_ID);
		
		button = (ImageView)findViewById(R.id.login);
		pic = (ImageView)findViewById(R.id.picture_pic);
		button.setOnClickListener((android.view.View.OnClickListener) this);
	}

	
	@SuppressWarnings({ "deprecation", "unused" })
	private void updateButtonImage() {
		if(fb.isSessionValid()){
			button.setImageResource(R.drawable.logout);
		}else{
			button.setImageResource(R.drawable.login);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public void LoginScreen(View view) {
		 Intent intent = new Intent(this, LoginActivity.class);
		 startActivity(intent);
	}

	
	public void RegisterScreen(View view){
		Intent intent = new Intent(this, RegisterActivity.class);
		startActivity(intent);
	}
	
	public void HotelsScreen(View view){
		Intent intent = new Intent(this, HotelsActivity.class);
		startActivity(intent);
	}

	


	@Override
	public void onClick(DialogInterface arg0, int arg1) {
	
	}
    
}
